from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import google.generativeai as genai
import os
import json
from dotenv import load_dotenv

load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# 💡 모델은 작동이 잘 되었던 2.5 버전으로 고정해두었습니다!
model = genai.GenerativeModel('gemini-2.5-flash')

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    previous_message: str
    user_response: str
    turn_count: int

safety_settings = {
    'HARM_CATEGORY_DANGEROUS_CONTENT': 'BLOCK_NONE',
    'HARM_CATEGORY_HARASSMENT': 'BLOCK_NONE'
}

@app.post("/api/start")
async def start_training():
    try:
        # 🔥 난이도가 대폭 상승된 첫 시작 프롬프트
        prompt = """
        너는 보이스피싱 사기꾼(검찰 사칭)이야. 타겟을 극도로 당황하게 만들 첫 대사를 시작해.
        타겟이 누를 수 있는 4가지 선택지도 만들어. (정답 1~2개, 오답 2~3개)
        
        [🚨 아주 중요: 선택지 난이도를 매우 높고 교묘하게 설정해!]
        - 오답(false): 타겟이 '안전한 확인 절차'라고 착각하게 만드는 함정. 
          (예: "문자로 공문을 보내주시면 확인해보겠습니다.", "검사님 소속과 성함을 알려주시면 메모하겠습니다.", "일단 시키는 대로 보안 앱을 깔고 확인해 본다.")
        - 정답(true): 단호하고 완벽한 차단 행동. 
          (예: "아무 대답 없이 즉시 전화를 끊고, 112에 직접 전화를 걸어 확인한다.")
        
        반드시 JSON 형식으로만 답변해:
        {
          "scammer_message": "사기꾼의 첫 대사",
          "options": [
            { "id": 1, "text": "선택지 1", "is_correct": true },
            { "id": 2, "text": "선택지 2", "is_correct": false },
            { "id": 3, "text": "선택지 3", "is_correct": false },
            { "id": 4, "text": "선택지 4", "is_correct": true }
          ]
        }
        """
        response = await model.generate_content_async(
            prompt, 
            generation_config={"response_mime_type": "application/json"},
            safety_settings=safety_settings
        )
        return json.loads(response.text)
    except Exception as e:
        print(f"🚨 백엔드 에러: {str(e)}")
        return {"error": str(e)}

@app.post("/api/chat")
async def continue_training(req: ChatRequest):
    try:
        is_last_turn = req.turn_count >= 10
        
        if is_last_turn:
            prompt = f"""
            훈련이 종료되었어. 사용자의 마지막 대처는 "{req.user_response}"였어.
            지금까지의 상황을 종합해서 '분석 리포트'를 JSON으로 작성해줘.
            score는 0~100점 사이로 깐깐하게 산출해.
            {{
              "scammer_message": "훈련이 종료되었습니다.",
              "is_finished": true,
              "report": {{
                "score": 점수,
                "feedback": "총평 작성",
                "tip": "실제 보이스피싱 예방을 위한 핵심 팁"
              }}
            }}
            """
        else:
            # 🔥 난이도가 상승된 대화 이어가기 프롬프트
            prompt = f"""
            너는 보이스피싱 사기꾼이야. 사용자의 대처 "{req.user_response}"에 반응하며 더 강하게 압박하고 협박하는 다음 사기 멘트를 쳐.
            
            사용자가 고를 수 있는 다음 4가지 선택지를 만들어. 
            [🚨 아주 중요: 선택지 난이도를 매우 높게 설정해!]
            - 오답(false): 사기꾼의 페이스에 말려들거나, 사기꾼이 유도하는 함정 행동. 
              (예: "알려주신 금융감독원 번호로 제가 직접 전화를 걸어보겠습니다.", "내 명의가 도용됐는지 확인 링크를 보내달라고 한다.", "일단 결백을 증명하기 위해 계좌 잔액만 알려준다.")
            - 정답(true): 가장 현명하고 안전한 대처 방안.
            
            반드시 JSON 형식으로 답변해:
            {{
              "scammer_message": "사기꾼의 다음 대사",
              "is_finished": false,
              "options": [
                {{ "id": 1, "text": "다음 선택지 1", "is_correct": false }},
                {{ "id": 2, "text": "다음 선택지 2", "is_correct": true }},
                {{ "id": 3, "text": "다음 선택지 3", "is_correct": false }},
                {{ "id": 4, "text": "다음 선택지 4", "is_correct": false }}
              ]
            }}
            """
        
        response = await model.generate_content_async(
            prompt, 
            generation_config={"response_mime_type": "application/json"},
            safety_settings=safety_settings
        )
        return json.loads(response.text)
    except Exception as e:
        print(f"🚨 백엔드 에러: {str(e)}")
        return {"error": str(e)}