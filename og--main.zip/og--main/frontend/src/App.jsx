import { useState } from 'react';
import axios from 'axios';

function App() {
  const [scammerMessage, setScammerMessage] = useState("");
  const [options, setOptions] = useState([]);
  const [turn, setTurn] = useState(1);
  const [score, setScore] = useState(0);
  const [report, setReport] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const startTraining = async () => {
    setIsLoading(true);
    setTurn(1);
    setScore(0);
    setReport(null);
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/start');
      setScammerMessage(response.data.scammer_message);
      setOptions(response.data.options);
    } catch (error) { alert("서버 연결 실패. 잠시 후 다시 시도해주세요."); }
    setIsLoading(false);
  };

  const handleOptionClick = async (option) => {
    if (option.is_correct) setScore(prev => prev + 10);
    
    setIsLoading(true);
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/chat', {
        previous_message: scammerMessage,
        user_response: option.text,
        turn_count: turn
      });

      if (response.data.is_finished) {
        setReport(response.data.report);
      } else {
        setScammerMessage(response.data.scammer_message);
        setOptions(response.data.options);
        setTurn(prev => prev + 1);
      }
    } catch (error) { alert("통신 에러가 발생했습니다."); }
    setIsLoading(false);
  };

  return (
    <div style={styles.container}>
      {/* 버튼 클릭 효과를 위한 스타일 태그 */}
      <style>{`
        .toss-button {
          transition: all 0.1s ease-out;
          cursor: pointer;
        }
        .toss-button:active {
          transform: scale(0.96);
          filter: brightness(0.9);
        }
        .option-button:active {
          background-color: #f2f4f6 !important;
        }
      `}</style>

      {!scammerMessage ? (
        <div style={styles.card}>
          <h1 style={styles.title}>보이스피싱<br/>대응 훈련</h1>
          <p style={styles.subtitle}>실전 같은 시뮬레이션으로<br/>안전하게 자산을 지키세요.</p>
          <button onClick={startTraining} className="toss-button" style={styles.primaryButton}>
            훈련 시작하기
          </button>
        </div>
      ) : report ? (
        <div style={styles.card}>
          <div style={styles.scoreBadge}>훈련 종료</div>
          <h2 style={styles.reportScore}>{report.score}점</h2>
          <div style={styles.reportBox}>
            <p style={styles.feedback}>{report.feedback}</p>
            <div style={styles.tipBox}>
              <strong>💡 안전 팁</strong>
              <p style={{margin: '8px 0 0', lineHeight: '1.5'}}>{report.tip}</p>
            </div>
          </div>
          <button onClick={startTraining} className="toss-button" style={styles.secondaryButton}>
            다시 훈련하기
          </button>
        </div>
      ) : (
        <div style={styles.card}>
          <div style={styles.progressHeader}>
            <span style={styles.turnLabel}>진행도 {turn}/10</span>
            <div style={styles.progressBar}>
              <div style={{...styles.progressFill, width: `${turn*10}%`}}></div>
            </div>
          </div>
          
          <div style={styles.scammerBubble}>
            <span style={styles.sender}>낯선 번호 (중앙지검)</span>
            <p style={styles.message}>{isLoading ? "상대방이 말하는 중..." : scammerMessage}</p>
          </div>

          <div style={styles.optionContainer}>
            {options.map((opt) => (
              <button 
                key={opt.id} 
                onClick={() => handleOptionClick(opt)} 
                className="toss-button option-button" 
                style={{...styles.optionButton, opacity: isLoading ? 0.6 : 1}} 
                disabled={isLoading}
              >
                {opt.text}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    backgroundColor: '#f2f4f6',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Pretendard, -apple-system, sans-serif',
    padding: '20px'
  },
  card: {
    backgroundColor: '#ffffff',
    width: '100%',
    maxWidth: '400px',
    borderRadius: '24px',
    padding: '32px',
    boxShadow: '0 8px 16px rgba(0,0,0,0.05)',
  },
  title: { fontSize: '28px', fontWeight: 'bold', lineHeight: '1.4', marginBottom: '12px', color: '#191f28', textAlign: 'left' },
  subtitle: { fontSize: '16px', color: '#4e5968', lineHeight: '1.6', marginBottom: '40px', textAlign: 'left' },
  primaryButton: { 
    width: '100%', padding: '18px', backgroundColor: '#3182f6', color: '#fff', 
    border: 'none', borderRadius: '16px', fontSize: '16px', fontWeight: 'bold'
  },
  secondaryButton: { 
    width: '100%', padding: '18px', backgroundColor: '#eff6ff', color: '#3182f6', 
    border: 'none', borderRadius: '16px', fontSize: '16px', fontWeight: 'bold', marginTop: '20px' 
  },
  progressHeader: { marginBottom: '24px' },
  turnLabel: { fontSize: '13px', color: '#8b95a1', marginBottom: '8px', display: 'block' },
  progressBar: { width: '100%', height: '4px', backgroundColor: '#e5e8eb', borderRadius: '2px' },
  progressFill: { height: '100%', backgroundColor: '#3182f6', borderRadius: '2px', transition: 'width 0.3s' },
  scammerBubble: { backgroundColor: '#f9fafb', borderRadius: '18px', padding: '20px', marginBottom: '32px' },
  sender: { fontSize: '12px', color: '#f04452', fontWeight: 'bold', marginBottom: '8px', display: 'block' },
  message: { fontSize: '17px', color: '#191f28', lineHeight: '1.5', margin: 0 },
  optionContainer: { display: 'flex', flexDirection: 'column', gap: '12px' },
  optionButton: { 
    width: '100%', padding: '16px', backgroundColor: '#fff', color: '#333d4b', 
    border: '1px solid #e5e8eb', borderRadius: '14px', fontSize: '15px', textAlign: 'left'
  },
  reportScore: { fontSize: '48px', fontWeight: 'bold', color: '#3182f6', margin: '12px 0 24px', textAlign: 'left' },
  reportBox: { borderTop: '1px solid #e5e8eb', paddingTop: '24px', textAlign: 'left' },
  feedback: { fontSize: '16px', color: '#333d4b', lineHeight: '1.6', marginBottom: '20px' },
  tipBox: { backgroundColor: '#f9fafb', padding: '16px', borderRadius: '12px' },
  scoreBadge: { display: 'inline-block', padding: '6px 12px', backgroundColor: '#e8f3ff', color: '#3182f6', borderRadius: '8px', fontSize: '12px', fontWeight: 'bold' }
};

export default App;